package com.example.Service;

import com.example.Entity.Item;
import com.example.exception.ResourceNotFoundException;

import java.util.List;
import java.util.Optional;

public interface ItemService  {
    Item storeItem (Item item);

    List<Item> getallItem();
    Item findbyname(String name) throws ResourceNotFoundException;

}
