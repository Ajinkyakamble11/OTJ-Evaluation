package com.example.Service;

import com.example.dto.Item;
import com.example.dto.OrderLineItemDTO;
import com.example.dto.SalesOrderRequestDTO;
import com.example.dto.SalesOrderResponseDTO;
import com.example.entity.OrderLineItem;
import com.example.entity.SalesOrder;
import com.example.event.CustomerCreatedEvent;
import com.example.fiegnclients.IItemServiceClient;
import com.example.repository.CustomerRepo;
import com.example.repository.OrderLineItemRepo;
import com.example.repository.SalesOrderRepo;
import feign.FeignException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.sql.Date;
import java.util.*;
import java.util.stream.Collectors;

@Service
@Slf4j
public class SalesOrderService implements ISalesOrderService {

    @Autowired
    private IItemServiceClient itemClient;

    @Autowired
    private SalesOrderRepo salesOrderRepo;

    @Autowired
    private CustomerRepo customerRepo;

    @Autowired
    private OrderLineItemRepo orderLineItemRepo;

    @Override
    public Item findItemByName(String name) throws Exception {
        try {
            return itemClient.findItemByName(name);
        } catch (FeignException.FeignClientException e) {
           // log.error("[FeignClientException] - {}", e.getLocalizedMessage());
            throw new Exception("[FeignClientException] - " + e.getLocalizedMessage());
        }
    }

    @Override
    @Transactional
    public SalesOrderResponseDTO createOrder(SalesOrderRequestDTO salesOrderRequestDTO) throws Exception {
       // log.info("start of createOrder()");
        /**
         * a. validate customer by verifying the table “customer_sos” with cust_id.
         * 	b. validate items by calling item service with item name
         * 	c. create order by inserting the order details in order table and items for the order details in the order_line_item table.
         *
         * 	Table:
         * 	1. sales_order – id, order_date, cust_id, order_desc, total_price
         * 	2. order_line_item – id, item_name, item_quantity, order_id
         */

        Optional<CustomerCreatedEvent> customerOptional = customerRepo.findById(salesOrderRequestDTO.getCustID());

        if (customerOptional.isPresent()) {


            Map<Item, Integer> itemCountMap = new HashMap<>();
            double totalPrice = getItemNamesList(itemCountMap, salesOrderRequestDTO.getListItems());

            SalesOrder order = new SalesOrder();
            order.setOrderDesc(salesOrderRequestDTO.getOrderDescription());
            order.setOrderDate(getDateFromString(salesOrderRequestDTO.getOrderDate()));
            order.setCustId(salesOrderRequestDTO.getCustID());
            order.setTotalPrice(totalPrice);

            SalesOrder savedOrder = salesOrderRepo.save(order);

            List<OrderLineItem> orderLineItemsToSave = new ArrayList<>();
            for (Map.Entry<Item, Integer> entry : itemCountMap.entrySet()) {
                Item key = entry.getKey();
                Integer qty = entry.getValue();

                OrderLineItem item = new OrderLineItem();
                item.setSalesOrder(savedOrder);
                item.setItemName(key.getName());
                item.setItemQuantity(qty);

                orderLineItemsToSave.add(item);
            }

            List<OrderLineItem> itemList = orderLineItemRepo.saveAll(orderLineItemsToSave);

          //  log.info(String.valueOf(itemList.size()));


            return getSalesOrderResponse(order, itemList);

        } else {
           // log.info("Customer not found!!");
            throw new Exception("Customer Not Found!!!");
        }
    }

    private SalesOrderResponseDTO getSalesOrderResponse(SalesOrder order, List<OrderLineItem> itemList) {
        SalesOrderResponseDTO responseDTO = new SalesOrderResponseDTO();

        responseDTO.setOrderId(order.getId());
        responseDTO.setOrderDescription(order.getOrderDesc());
        responseDTO.setOrderLineItemsList(orderLineItemEntityToDTO(itemList));

        return responseDTO;
    }

    private List<OrderLineItemDTO> orderLineItemEntityToDTO(List<OrderLineItem> itemList) {
        return itemList.stream()
                .map(item -> new OrderLineItemDTO(item.getId(), item.getItemName(), item.getItemQuantity()))
                .collect(Collectors.toList());
    }

    private double getItemNamesList(Map<Item, Integer> itemCountMap, List<String> itemNamesList) throws Exception {
        double totalPrice = 0.0;
        for (String itemName : itemNamesList) {
            Item item = findItemByName(itemName);
            totalPrice += item.getPrice();

            if (itemCountMap.get(item) != null) {
                Integer qty = itemCountMap.get(item);
                qty++;
                itemCountMap.replace(item, qty);
            } else {
                itemCountMap.put(item, 1);
            }
        }

        return totalPrice;
    }

    private Date getDateFromString(String date) {
        return Date.valueOf(date);
    }

	@Override
	public List<SalesOrder> all() {
		
		return salesOrderRepo.findAll();
	}
//
//	@Override
//	public Optional<SalesOrder> get(long id) {
//		Optional<SalesOrder> orderResult = salesOrderRepo.findById(id);
//		if (!orderResult.isPresent()) {
//			return null;
//		}
//		
//		return orderResult;
//	}
}
