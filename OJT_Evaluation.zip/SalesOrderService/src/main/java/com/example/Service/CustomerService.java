package com.example.Service;

import com.example.event.CustomerCreatedEvent;
import com.example.repository.CustomerRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class CustomerService {


    @Autowired
    private CustomerRepo customerRepo;


    public void subscribeToCustomerCreatedEvent(CustomerCreatedEvent customerCreatedEvent) {
        customerRepo.save(customerCreatedEvent);
    }


}
