package com.example.Service.ServiceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.Entity.Customer;
import com.example.Exception.ResourcesNotFoundException;
import com.example.Repository.Customer_Repo;
import com.example.Service.Customer_Service;

@Service                                      
public class Customer_serviceimpl implements Customer_Service {
	@Autowired
	private Customer_Repo customer_repo;


	@Override
	public Customer createcustomer(Customer customer) {
		
		return customer_repo.save(customer);
	}

	@Override
	public List<Customer> getallcusomer() {
		
		return customer_repo.findAll();
	}

	@Override
	public Customer getcustomerbyId(int id) {
		
		return customer_repo.findById(id).orElseThrow(() -> new ResourcesNotFoundException("Customer", "id", id));
	}

}
