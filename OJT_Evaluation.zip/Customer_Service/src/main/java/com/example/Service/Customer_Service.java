package com.example.Service;

import java.util.List;

import com.example.Entity.Customer;

public interface Customer_Service {
	Customer createcustomer(Customer customer);
	List<Customer> getallcusomer();
	Customer getcustomerbyId(int id);



}
