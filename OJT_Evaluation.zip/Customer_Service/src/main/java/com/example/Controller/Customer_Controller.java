package com.example.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.Entity.Customer;

import com.example.Service.Customer_Service;
import com.example.Service.ServiceImpl.EventPublisher;
import com.example.event.CustomerCreatedEvent;

@RestController

public class Customer_Controller {
	
	@Autowired
	private Customer_Service customer_service;
	
	@Autowired
	private EventPublisher eventPublisher;
	
//	public Customer_Controller(ApplicationEventPublisher eventPublisher) {
//		super();
//		this.eventPublisher = eventPublisher;
//	}

//	@PostMapping("/customer")
//    public ResponseEntity<String> createCustomer(@RequestBody Customer cust){
//		
//		
//		
//	Customer customer=	customer_service.createcustomer(cust);
//		CustomerCreatedEvent event = new CustomerCreatedEvent(customer.getId(),customer.getFirst_name(),customer.getLast_name(), customer.getEmail());
//		eventPublisher.publishEvent(event);
//		
//		return  ResponseEntity.ok("Customer created Successfully "+"with this details"+"\n "+"CustomerFirstName:"+" "+customer.getFirst_name()+"\n"+"CustomerLastName:"+" "+customer.getLast_name()+"\n"+"CustomerEmail:"+" "+customer.getEmail());
//		
//	}
	
	@PostMapping("/customer")
    public ResponseEntity<Customer> register(@RequestBody Customer cust) {
        return new ResponseEntity<Customer>(customer_service.createcustomer(cust) ,HttpStatus.CREATED);
    }
	
	@GetMapping("/customer")
	public List<Customer> showall(){
		return customer_service.getallcusomer();
		
	}
	
	@GetMapping("customer/{id}")
	public ResponseEntity<Customer> getcustomer(@PathVariable("id") int id ){
		return new ResponseEntity<Customer>(customer_service.getcustomerbyId(id),HttpStatus.OK);
		
	}
	
}
